from data_base import read_contact,rewrite

def data_To_List():
    list_of_contact = []
    temp_list = read_contact().split('\n\n')
    for i in temp_list:
        list_of_contact.append(i.split('\n'))
    return list_of_contact

def search(data_list: list, f_c):
    find_contact = f_c
    for i in range(len(data_list)):
        for j in range(len(data_list[i])):
            if find_contact.lower() in data_list[i][j].lower():
                return data_list[i]

def delete_contact(data_list: list):
    contact = input('Contact for delete: ')
    dict_for_search = {}
    for i in range(len(data_list)):
        if contact in data_list[i]:
            dict_for_search[i] = data_list[i]
    print(dict_for_search)
    while (key_ := int(input('Enter number of contact for delete: '))) not in dict_for_search:
        print('Wrong number! Enter number before ":" ')
    else:
        data_list.remove(dict_for_search[key_])
    return data_list

def correction_data(data_list: list):
    data_for_search = input('Enter name: ')
    dict_for_search = {}
    for i in range(len(data_list)):
        if data_for_search in data_list[i]:
            dict_for_search[i] = data_list[i]
    print(dict_for_search)
    while (key_ := int(input('Enter number of contact for change: '))) not in dict_for_search:
        print('Wrong number! Enter number before ":" ')
    else:
        print('What do you want to change?')
        while (num := int(input('0-Name, 1-Surname, 2-Number'))) not in range(3):
            print('Wrong command!')
        else:
            data_list[key_][num] = input('Enter correct data: ')
    return data_list

def import_file(file_name):
    with open(file_name, 'r') as data:
        str_data = data.read()
    str_first_data = read_contact()
    new_list_of_contact = []
    list_of_contact = (str_first_data + '\n\n' + str_data).split('\n\n')
    list_of_contact = set(list_of_contact)
    list_of_contact = list(list_of_contact)
    for i in list_of_contact:
        new_list_of_contact.append(i.split('\n'))
    return new_list_of_contact

def sort_ (data_list: list):
    print(data_list.sort())